--[[
    BadLands Studio's | Advanced Trucking
    Config - everything you will normally want to tweak lives here.
]]

Config = {}

-- 'auto' detects qbx_core > qb-core > es_extended. Or force: 'esx' | 'qbcore' | 'qbox'
Config.Framework = 'auto'

Config.Account = 'bank'          -- account used for deposits & payouts: 'bank' or 'cash'
Config.Debug = false

-- Job gate. If RequireJob is true, only players with JobName can use the dispatch.
Config.RequireJob = false
Config.JobName = 'trucker'

---------------------------------------------------------------------------
-- DEPOT  (default coordinates are a starting point - stand where you want
-- each spot and copy your own vector4s in. Keep truckSpawn clear of props.)
---------------------------------------------------------------------------
Config.Depot = {
    label = 'BadLands Freight Depot',
    ped = { model = 's_m_m_trucker_01', coords = vector4(1197.35, -3253.70, 6.10, 90.0) },
    coords = vector3(1197.35, -3253.70, 6.10),         -- interaction point (dispatch)
    truckSpawn = vector4(1214.00, -3236.00, 5.60, 270.0),
    returnPoint = vector3(1203.00, -3238.00, 5.60),     -- return truck here for deposit refund
    blip = { sprite = 477, color = 47, scale = 0.85, label = 'Trucking Depot' },
}

Config.InteractDistance = 2.5
Config.ReturnRadius = 9.0
Config.DeliveryRadius = 12.0
Config.TrailerOffset = 10.5       -- metres behind the cab the trailer spawns. Tune if it will not auto-hitch.
Config.UnloadTime = 6000          -- ms to unload at the drop-off
Config.AutoAttachTrailer = true   -- false = trailer spawns beside the truck and the driver hitches it manually

---------------------------------------------------------------------------
-- ECONOMY & PROGRESSION
---------------------------------------------------------------------------
Config.BoardSize = 8              -- contracts on the board
Config.RefreshCooldown = 20       -- seconds between board refreshes
Config.BasePay = 450
Config.PayPerKm = 210
Config.LevelPayBonus = 0.04       -- +4% pay per level above 1
Config.RoadFactor = 1.35          -- straight line -> approx road distance
Config.AvgSpeed = 17.0            -- m/s used to build the time limit (about 61 km/h)
Config.TimeBuffer = 150           -- extra seconds added to every time limit
Config.FailMultiplier = 1.6       -- contract fails at time limit x this
Config.XpPerKm = 12

Config.RushChance = 22            -- % of contracts that are rush jobs
Config.RushPayMult = 1.35
Config.RushTimeMult = 0.75

Config.OnTimeBonus = 0.10         -- +10% if delivered with 25% of the time left
Config.LatePenalty = 0.20         -- -20% if over the time limit
Config.DamagePenalty = 0.85       -- how much of the pay damage can eat (scaled per cargo)

-- Anti-cheat: the server refuses deliveries completed faster than this (m/s over straight line)
Config.MaxPossibleSpeed = 60.0

-- XP needed to REACH each level
Config.Levels = {
    [1] = 0, [2] = 600, [3] = 1600, [4] = 3500, [5] = 6500,
    [6] = 11000, [7] = 17500, [8] = 26000, [9] = 38000, [10] = 55000,
}

---------------------------------------------------------------------------
-- TRUCKS (rented per contract, deposit refunded on return, scaled by damage)
---------------------------------------------------------------------------
Config.Trucks = {
    { model = 'hauler',   label = 'MTL Hauler',        deposit = 1200, minLevel = 1,  power = 55, note = 'Reliable starter rig' },
    { model = 'packer',   label = 'MTL Packer',        deposit = 2000, minLevel = 3,  power = 68, note = 'Strong on long hauls' },
    { model = 'phantom',  label = 'Jobuilt Phantom',   deposit = 2800, minLevel = 4,  power = 80, note = 'Fast and stable' },
    { model = 'hauler2',  label = 'MTL Hauler Custom', deposit = 3800, minLevel = 6,  power = 90, note = 'Tuned for heavy freight' },
    { model = 'phantom3', label = 'Phantom Custom',    deposit = 5200, minLevel = 8,  power = 100, note = 'Top of the fleet' },
}

---------------------------------------------------------------------------
-- CARGO
-- payMult: pay multiplier | damageMult: how harshly damage cuts the pay
---------------------------------------------------------------------------
Config.Cargo = {
    { id = 'general',  label = 'General freight',     trailer = 'trailers',    icon = 'box',   payMult = 1.00, xp = 60,  minLevel = 1, damageMult = 1.0 },
    { id = 'reefer',   label = 'Refrigerated goods',  trailer = 'trailers2',   icon = 'snow',  payMult = 1.20, xp = 80,  minLevel = 2, damageMult = 1.2, fragile = true },
    { id = 'timber',   label = 'Timber',              trailer = 'trailerlogs', icon = 'log',   payMult = 1.30, xp = 95,  minLevel = 3, damageMult = 1.1 },
    { id = 'fuel',     label = 'Fuel tanker',         trailer = 'tanker',      icon = 'flame', payMult = 1.60, xp = 130, minLevel = 4, damageMult = 1.6, hazmat = true },
    { id = 'vehicles', label = 'Vehicle transport',   trailer = 'tr4',         icon = 'car',   payMult = 1.45, xp = 110, minLevel = 5, damageMult = 1.4, fragile = true },
    { id = 'container',label = 'Shipping container',  trailer = 'docktrailer', icon = 'crate', payMult = 1.80, xp = 150, minLevel = 7, damageMult = 1.0 },
}

---------------------------------------------------------------------------
-- DESTINATIONS
---------------------------------------------------------------------------
Config.Destinations = {
    { label = 'Sandy Shores Airfield',   region = 'Blaine County', coords = vector3(1730.0, 3310.0, 41.2) },
    { label = 'Grand Senora Gas Depot',  region = 'Blaine County', coords = vector3(2680.0, 3265.0, 55.2) },
    { label = 'Davis Quartz Quarry',     region = 'Blaine County', coords = vector3(2950.0, 2790.0, 41.0) },
    { label = 'Humane Labs Gate',        region = 'Blaine County', coords = vector3(3615.0, 3745.0, 28.7) },
    { label = 'Grapeseed Farms',         region = 'Blaine County', coords = vector3(2038.0, 4730.0, 41.1) },
    { label = 'Paleto Sawmill',          region = 'Paleto',        coords = vector3(-545.0, 5310.0, 74.0) },
    { label = 'Paleto Bay Docks',        region = 'Paleto',        coords = vector3(-290.0, 6310.0, 31.5) },
    { label = 'Chumash Warehouse',       region = 'West Coast',    coords = vector3(-3240.0, 1000.0, 12.6) },
    { label = 'Los Santos Airport Cargo',region = 'Los Santos',    coords = vector3(-1050.0, -2600.0, 13.9) },
    { label = 'Vinewood Hills Depot',    region = 'Los Santos',    coords = vector3(-770.0, 330.0, 85.7) },
    { label = 'Harmony Truck Stop',      region = 'Blaine County', coords = vector3(1180.0, 2640.0, 37.9) },
}

---------------------------------------------------------------------------
-- VEHICLE HOOKS (client side). Plug in your own keys/fuel scripts here.
---------------------------------------------------------------------------
Config.GiveKeys = function(veh, plate)
    if GetResourceState('qbx_vehiclekeys') == 'started' then
        pcall(function() exports.qbx_vehiclekeys:GiveKeys(veh) end)
    elseif GetResourceState('qb-vehiclekeys') == 'started' then
        TriggerEvent('vehiclekeys:client:SetOwner', plate)
    elseif GetResourceState('wasabi_carlock') == 'started' then
        exports.wasabi_carlock:GiveKey(plate)
    elseif GetResourceState('cd_garage') == 'started' then
        TriggerEvent('cd_garage:AddKeys', plate)
    elseif GetResourceState('okokGarage') == 'started' then
        TriggerServerEvent('okokGarage:GiveKeys', plate)
    end
end

Config.SetFuel = function(veh)
    if GetResourceState('ox_fuel') == 'started' then
        Entity(veh).state.fuel = 100.0
    elseif GetResourceState('LegacyFuel') == 'started' then
        exports.LegacyFuel:SetFuel(veh, 100)
    elseif GetResourceState('cdn-fuel') == 'started' then
        exports['cdn-fuel']:SetFuel(veh, 100)
    elseif GetResourceState('ps-fuel') == 'started' then
        exports['ps-fuel']:SetFuel(veh, 100)
    else
        SetVehicleFuelLevel(veh, 100.0)
    end
end
