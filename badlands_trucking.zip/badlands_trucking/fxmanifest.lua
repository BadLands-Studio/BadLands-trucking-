fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'badlands_trucking'
author "BadLands Studio's"
description "Advanced semi trucking job with dispatch tablet UI | ESX, QBCore & QBox"
version '1.0.0'

dependency 'oxmysql'

shared_script 'config.lua'

client_scripts {
    'client/bridge.lua',
    'client/main.lua',
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server/bridge.lua',
    'server/main.lua',
}

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/script.js',
}
