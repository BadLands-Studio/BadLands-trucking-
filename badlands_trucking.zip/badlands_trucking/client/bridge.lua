--[[ BadLands Studio's | Advanced Trucking | Client bridge ]]

local framework, core

local function detect()
    if Config.Framework ~= 'auto' then return Config.Framework end
    if GetResourceState('qbx_core') == 'started' then return 'qbox' end
    if GetResourceState('qb-core') == 'started' then return 'qbcore' end
    if GetResourceState('es_extended') == 'started' then return 'esx' end
end

CreateThread(function()
    local waited = 0
    while not framework and waited < 30000 do
        framework = detect()
        if not framework then Wait(500) waited = waited + 500 end
    end
    if framework == 'esx' then
        core = exports['es_extended']:getSharedObject()
    elseif framework == 'qbcore' then
        core = exports['qb-core']:GetCoreObject()
    end
end)

function Notify(msg, nType)
    nType = nType or 'info'
    if framework == 'esx' and core then
        core.ShowNotification(msg)
    elseif framework == 'qbcore' and core then
        core.Functions.Notify(msg, nType == 'info' and 'primary' or nType)
    elseif framework == 'qbox' then
        exports.qbx_core:Notify(msg, nType == 'info' and 'inform' or nType)
    else
        BeginTextCommandThefeedPost('STRING')
        AddTextComponentSubstringPlayerName(msg)
        EndTextCommandThefeedPostTicker(false, true)
    end
end

RegisterNetEvent('badlands_trucking:notify', function(msg, nType)
    Notify(msg, nType)
end)
