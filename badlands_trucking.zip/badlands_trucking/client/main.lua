--[[ BadLands Studio's | Advanced Trucking | Client ]]

local tabletOpen = false
local job, truck, trailer = nil, nil, nil
local stage = 'idle'            -- idle | deliver | unloading | awaiting | return
local startTime = 0
local routeBlip, trailerBlip, depotBlip, depotPed

local function clamp(v, lo, hi) return math.max(lo, math.min(hi, v)) end

local function loadModel(name)
    local hash = joaat(name)
    if not IsModelInCdimage(hash) then return nil end
    RequestModel(hash)
    local timeout = GetGameTimer() + 10000
    while not HasModelLoaded(hash) do
        if GetGameTimer() > timeout then return nil end
        Wait(0)
    end
    return hash
end

local function removeVehicle(veh)
    if veh and DoesEntityExist(veh) then
        SetEntityAsMissionEntity(veh, true, true)
        DeleteEntity(veh)
    end
end

local function draw3D(x, y, z, text)
    SetDrawOrigin(x, y, z, 0)
    SetTextScale(0.34, 0.34)
    SetTextFont(4)
    SetTextCentre(true)
    SetTextColour(255, 255, 255, 230)
    SetTextOutline()
    BeginTextCommandDisplayText('STRING')
    AddTextComponentSubstringPlayerName(text)
    EndTextCommandDisplayText(0.0, 0.0)
    ClearDrawOrigin()
end

local function setRoute(coords, label, sprite, color)
    if routeBlip then RemoveBlip(routeBlip) end
    routeBlip = AddBlipForCoord(coords.x, coords.y, coords.z)
    SetBlipSprite(routeBlip, sprite)
    SetBlipColour(routeBlip, color)
    SetBlipScale(routeBlip, 0.9)
    SetBlipRoute(routeBlip, true)
    SetBlipRouteColour(routeBlip, color)
    BeginTextCommandSetBlipName('STRING')
    AddTextComponentSubstringPlayerName(label)
    EndTextCommandSetBlipName(routeBlip)
end

local function clearBlips()
    if routeBlip then RemoveBlip(routeBlip) routeBlip = nil end
    if trailerBlip then RemoveBlip(trailerBlip) trailerBlip = nil end
end

local function resetJob(deleteRig)
    clearBlips()
    SendNUIMessage({ action = 'hud', show = false })
    SendNUIMessage({ action = 'progress', hide = true })
    if deleteRig then
        removeVehicle(trailer)
        removeVehicle(truck)
    end
    job, truck, trailer, stage = nil, nil, nil, 'idle'
end

---------------------------------------------------------------------------
-- DEPOT PED + BLIP
---------------------------------------------------------------------------
CreateThread(function()
    local d = Config.Depot
    local hash = loadModel(d.ped.model)
    if hash then
        local c = d.ped.coords
        depotPed = CreatePed(4, hash, c.x, c.y, c.z - 1.0, c.w, false, false)
        SetEntityInvincible(depotPed, true)
        SetBlockingOfNonTemporaryEvents(depotPed, true)
        FreezeEntityPosition(depotPed, true)
        TaskStartScenarioInPlace(depotPed, 'WORLD_HUMAN_CLIPBOARD', 0, true)
        SetModelAsNoLongerNeeded(hash)
    end

    depotBlip = AddBlipForCoord(d.coords.x, d.coords.y, d.coords.z)
    SetBlipSprite(depotBlip, d.blip.sprite)
    SetBlipColour(depotBlip, d.blip.color)
    SetBlipScale(depotBlip, d.blip.scale)
    SetBlipAsShortRange(depotBlip, true)
    BeginTextCommandSetBlipName('STRING')
    AddTextComponentSubstringPlayerName(d.blip.label)
    EndTextCommandSetBlipName(depotBlip)
end)

---------------------------------------------------------------------------
-- TABLET
---------------------------------------------------------------------------
local function openTablet()
    if tabletOpen then return end
    tabletOpen = true
    SetNuiFocus(true, true)
    SendNUIMessage({ action = 'open' })
    TriggerServerEvent('badlands_trucking:requestData', false)
end

local function closeTablet()
    if not tabletOpen then return end
    tabletOpen = false
    SetNuiFocus(false, false)
    SendNUIMessage({ action = 'close' })
end

RegisterNetEvent('badlands_trucking:receiveData', function(data)
    if not tabletOpen then return end
    data.active = job and {
        cargo = job.cargoLabel,
        dest = job.destLabel,
        stage = stage,
    } or nil
    SendNUIMessage({ action = 'data', data = data })
end)

RegisterNUICallback('close', function(_, cb) closeTablet() cb('ok') end)
RegisterNUICallback('refresh', function(_, cb)
    TriggerServerEvent('badlands_trucking:requestData', true)
    cb('ok')
end)
RegisterNUICallback('accept', function(d, cb)
    if job then
        Notify('You already have an active contract.', 'error')
    else
        TriggerServerEvent('badlands_trucking:accept', d.id, d.truck)
    end
    cb('ok')
end)
RegisterNUICallback('abandon', function(_, cb)
    ExecuteCommand('canceltruck')
    closeTablet()
    cb('ok')
end)

---------------------------------------------------------------------------
-- JOB START
---------------------------------------------------------------------------
local function spawnRig(data)
    local sp = Config.Depot.truckSpawn
    if GetClosestVehicle(sp.x, sp.y, sp.z, 10.0, 0, 71) ~= 0 then
        return false, 'The loading bay is blocked. Clear it and try again.'
    end

    local th = loadModel(data.truck)
    local trh = loadModel(data.trailer)
    if not th or not trh then return false, 'Vehicle models failed to load.' end

    truck = CreateVehicle(th, sp.x, sp.y, sp.z, sp.w, true, false)
    SetEntityAsMissionEntity(truck, true, true)
    SetVehicleOnGroundProperly(truck)
    SetVehicleDirtLevel(truck, 0.0)
    SetVehicleNumberPlateText(truck, ('BL%04d'):format(math.random(0, 9999)))

    local pos
    if Config.AutoAttachTrailer then
        pos = GetOffsetFromEntityInWorldCoords(truck, 0.0, -Config.TrailerOffset, 0.0)
    else
        pos = GetOffsetFromEntityInWorldCoords(truck, 8.0, -4.0, 0.0)
    end
    trailer = CreateVehicle(trh, pos.x, pos.y, pos.z, sp.w, true, false)
    SetEntityAsMissionEntity(trailer, true, true)
    SetVehicleOnGroundProperly(trailer)

    if Config.AutoAttachTrailer then
        Wait(300)
        AttachVehicleToTrailer(truck, trailer, 1.1)
        Wait(500)
        if not IsVehicleAttachedToTrailer(truck) then
            AttachVehicleToTrailer(truck, trailer, 12.0)
        end
    end

    local plate = (GetVehicleNumberPlateText(truck) or ''):gsub('%s+$', '')
    Config.SetFuel(truck)
    Config.GiveKeys(truck, plate)
    SetVehicleEngineOn(truck, true, true, false)
    SetModelAsNoLongerNeeded(th)
    SetModelAsNoLongerNeeded(trh)
    TaskWarpPedIntoVehicle(PlayerPedId(), truck, -1)
    return true
end

RegisterNetEvent('badlands_trucking:startJob', function(data)
    closeTablet()
    CreateThread(function()
        local ok, err = spawnRig(data)
        if not ok then
            removeVehicle(truck) removeVehicle(trailer)
            truck, trailer = nil, nil
            Notify(err, 'error')
            TriggerServerEvent('badlands_trucking:abort')
            return
        end
        job = data
        stage = 'deliver'
        startTime = GetGameTimer()
        setRoute(data.dest, data.destLabel, 477, 5)
        Notify(('Contract started: %s to %s. Follow the GPS route.'):format(data.cargoLabel, data.destLabel), 'success')
    end)
end)

local function cancelJob(msg)
    if not job then return Notify('You have no active contract.', 'error') end
    TriggerServerEvent('badlands_trucking:cancel')
    if msg then Notify(msg, 'error') end
    resetJob(true)
end

RegisterCommand('canceltruck', function() cancelJob() end, false)

---------------------------------------------------------------------------
-- DELIVERY
---------------------------------------------------------------------------
local function startUnload()
    stage = 'unloading'
    local duration = Config.UnloadTime or 6000
    FreezeEntityPosition(truck, true)
    SendNUIMessage({ action = 'progress', label = 'Unloading ' .. job.cargoLabel, duration = duration })
    Wait(duration)
    if not job or not DoesEntityExist(trailer) then return end
    FreezeEntityPosition(truck, false)

    local health = clamp(math.floor(GetVehicleBodyHealth(trailer) / 10.0), 0, 100)
    stage = 'awaiting'
    TriggerServerEvent('badlands_trucking:complete', { trailerHealth = health })
    SetTimeout(6000, function()
        if stage == 'awaiting' then stage = 'deliver' end -- server rejected, let the driver retry
    end)
end

RegisterNetEvent('badlands_trucking:delivered', function(receipt)
    if not job then return end
    if truck and DoesEntityExist(truck) then DetachVehicleFromTrailer(truck) end
    Wait(300)
    removeVehicle(trailer)
    trailer = nil
    if trailerBlip then RemoveBlip(trailerBlip) trailerBlip = nil end

    stage = 'return'
    setRoute(Config.Depot.returnPoint, Config.Depot.label, 477, 2)
    SendNUIMessage({ action = 'receipt', data = receipt })
end)

RegisterNetEvent('badlands_trucking:returned', function(refund, lost)
    CreateThread(function()
        local ped = PlayerPedId()
        if truck and DoesEntityExist(truck) then
            TaskLeaveVehicle(ped, truck, 0)
            Wait(1500)
        end
        local msg = ('Truck returned. Deposit refund: $%d'):format(refund)
        if lost and lost > 0 then msg = msg .. (' ($%d held back for damage)'):format(lost) end
        Notify(msg, 'success')
        resetJob(true)
    end)
end)

---------------------------------------------------------------------------
-- MAIN LOOPS
---------------------------------------------------------------------------
CreateThread(function()
    while true do
        local sleep = 1000
        local ped = PlayerPedId()
        local pc = GetEntityCoords(ped)

        -- Dispatch desk
        local dd = #(pc - Config.Depot.coords)
        if dd < 12.0 then
            sleep = 0
            if dd < Config.InteractDistance and not tabletOpen and stage ~= 'unloading' then
                draw3D(Config.Depot.coords.x, Config.Depot.coords.y, Config.Depot.coords.z + 1.0, '[E] Open dispatch')
                if IsControlJustReleased(0, 38) then openTablet() end
            end
        end

        if job and truck and DoesEntityExist(truck) then
            local tc = GetEntityCoords(truck)
            local inTruck = GetVehiclePedIsIn(ped, false) == truck

            if stage == 'deliver' then
                local d = #(tc - job.dest)
                if d < 150.0 then
                    sleep = 0
                    local r = Config.DeliveryRadius
                    DrawMarker(1, job.dest.x, job.dest.y, job.dest.z - 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                        r * 2.0, r * 2.0, 2.2, 245, 183, 5, 90, false, false, 2, false, nil, nil, false)
                    if d < r and inTruck then
                        if not IsVehicleAttachedToTrailer(truck) then
                            draw3D(job.dest.x, job.dest.y, job.dest.z + 1.2, 'Hitch your trailer to unload')
                        elseif GetEntitySpeed(truck) > 1.0 then
                            draw3D(job.dest.x, job.dest.y, job.dest.z + 1.2, 'Stop the truck to unload')
                        else
                            draw3D(job.dest.x, job.dest.y, job.dest.z + 1.2, '[E] Unload cargo')
                            if IsControlJustReleased(0, 38) then
                                CreateThread(startUnload)
                            end
                        end
                    end
                end
            elseif stage == 'return' then
                local rp = Config.Depot.returnPoint
                local d = #(tc - rp)
                if d < 150.0 then
                    sleep = 0
                    local r = Config.ReturnRadius
                    DrawMarker(1, rp.x, rp.y, rp.z - 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                        r * 2.0, r * 2.0, 2.2, 31, 122, 77, 90, false, false, 2, false, nil, nil, false)
                    if d < r and inTruck then
                        if GetEntitySpeed(truck) > 2.0 then
                            draw3D(rp.x, rp.y, rp.z + 1.2, 'Stop the truck to return it')
                        else
                            draw3D(rp.x, rp.y, rp.z + 1.2, '[E] Return truck')
                            if IsControlJustReleased(0, 38) then
                                local health = clamp(math.floor(GetVehicleBodyHealth(truck) / 10.0), 0, 100)
                                TriggerServerEvent('badlands_trucking:returnTruck', health)
                            end
                        end
                    end
                end
            end
        end

        Wait(sleep)
    end
end)

-- Job monitor + HUD feed
CreateThread(function()
    while true do
        Wait(500)
        if job then
            if not truck or not DoesEntityExist(truck) then
                cancelJob('Your truck was lost. Contract cancelled.')
            elseif stage ~= 'return' and (not trailer or not DoesEntityExist(trailer) or IsEntityDead(trailer)) then
                cancelJob('Your trailer was destroyed. Contract cancelled.')
            else
                local elapsed = (GetGameTimer() - startTime) / 1000.0
                if stage ~= 'return' and elapsed > job.timeLimit * Config.FailMultiplier then
                    cancelJob('The client cancelled the contract. You ran out of time.')
                else
                    local attached = IsVehicleAttachedToTrailer(truck)
                    local target = stage == 'return' and Config.Depot.returnPoint or job.dest
                    local meters = #(GetEntityCoords(truck) - target)

                    -- Flag a detached trailer on the map
                    if stage == 'deliver' and not attached and trailer then
                        if not trailerBlip then
                            trailerBlip = AddBlipForEntity(trailer)
                            SetBlipSprite(trailerBlip, 479)
                            SetBlipColour(trailerBlip, 1)
                            SetBlipFlashes(trailerBlip, true)
                        end
                    elseif trailerBlip then
                        RemoveBlip(trailerBlip)
                        trailerBlip = nil
                    end

                    SendNUIMessage({
                        action = 'hud',
                        show = true,
                        data = {
                            stage = stage,
                            cargo = job.cargoLabel,
                            dest = stage == 'return' and Config.Depot.label or job.destLabel,
                            meters = math.floor(meters),
                            left = stage == 'return' and nil or math.floor(job.timeLimit - elapsed),
                            rush = job.rush,
                            fragile = job.fragile,
                            hazmat = job.hazmat,
                            attached = attached,
                            speed = math.floor(GetEntitySpeed(truck) * 3.6),
                            truckHealth = clamp(math.floor(GetVehicleBodyHealth(truck) / 10.0), 0, 100),
                            trailerHealth = trailer and DoesEntityExist(trailer)
                                and clamp(math.floor(GetVehicleBodyHealth(trailer) / 10.0), 0, 100) or nil,
                        },
                    })
                end
            end
        end
    end
end)

---------------------------------------------------------------------------
-- CLEANUP
---------------------------------------------------------------------------
AddEventHandler('onResourceStop', function(res)
    if res ~= GetCurrentResourceName() then return end
    SetNuiFocus(false, false)
    clearBlips()
    if depotBlip then RemoveBlip(depotBlip) end
    if depotPed and DoesEntityExist(depotPed) then DeleteEntity(depotPed) end
    removeVehicle(trailer)
    removeVehicle(truck)
end)
