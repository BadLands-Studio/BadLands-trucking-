/* BadLands Studio's | Advanced Trucking | NUI */

const $ = (id) => document.getElementById(id);
const money = (n) => '$' + Math.floor(n || 0).toLocaleString('en-US');
const post = (name, data = {}) =>
  fetch(`https://${GetParentResourceName()}/${name}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json; charset=UTF-8' },
    body: JSON.stringify(data),
  }).catch(() => {});

const state = { data: null, tab: 'board', contract: null, truck: null };
let receiptTimer = null;
let progressTimer = null;

/* ---------- helpers ---------- */
function levelFromXp(xp, levels) {
  const list = Array.isArray(levels) ? levels : Object.values(levels || {});
  let lvl = 1;
  list.forEach((need, i) => { if (xp >= need) lvl = i + 1; });
  return lvl;
}
function esc(s) {
  const d = document.createElement('div');
  d.textContent = s == null ? '' : String(s);
  return d.innerHTML;
}
function fmtTime(sec) {
  const neg = sec < 0;
  sec = Math.abs(sec);
  const m = Math.floor(sec / 60), s = sec % 60;
  return (neg ? '+' : '') + m + ':' + String(s).padStart(2, '0');
}
function fmtDist(m) { return m >= 1000 ? (m / 1000).toFixed(1) + ' km' : m + ' m'; }

/* ---------- tablet ---------- */
function openTablet() {
  state.contract = null;
  $('tablet').classList.remove('hidden');
  $('tablet').classList.remove('show');
  void $('tablet').offsetWidth; // restart entrance animation
  $('tablet').classList.add('show');
  switchTab('board');
  updateDock();
}
function closeTablet() { $('tablet').classList.add('hidden'); }

function switchTab(tab) {
  state.tab = tab;
  document.querySelectorAll('.tab').forEach((b) => b.classList.toggle('on', b.dataset.tab === tab));
  document.querySelectorAll('.panel').forEach((p) => p.classList.toggle('on', p.id === 'panel-' + tab));
  $('dock').classList.toggle('hidden', tab === 'profile' || tab === 'leaders');
}

function render() {
  const d = state.data;
  if (!d) return;

  const p = d.profile;
  $('depotName').textContent = d.depot;
  $('dName').textContent = p.name;
  $('dLevel').textContent = p.level;
  const span = p.next ? p.next - p.base : 1;
  const pct = p.next ? Math.min(100, ((p.xp - p.base) / span) * 100) : 100;
  $('dXpFill').style.width = pct + '%';
  $('dXpText').textContent = p.next ? `${p.xp.toLocaleString()} / ${p.next.toLocaleString()} XP` : `${p.xp.toLocaleString()} XP (max level)`;
  $('balLabel').textContent = d.account === 'cash' ? 'Cash' : 'Bank';
  $('balance').textContent = money(d.balance);

  // Active contract banner
  const banner = $('activeBanner');
  if (d.active) {
    banner.classList.remove('hidden');
    $('activeText').textContent = `${d.active.cargo} to ${d.active.dest}`;
  } else {
    banner.classList.add('hidden');
  }

  // Default truck: cheapest unlocked
  if (!state.truck || !d.trucks.find((t) => t.model === state.truck && !t.locked)) {
    const first = d.trucks.find((t) => !t.locked);
    state.truck = first ? first.model : null;
  }

  renderTickets();
  renderFleet();
  renderProfile();
  renderLeaders();
  updateDock();
}

function renderTickets() {
  const wrap = $('tickets');
  const list = state.data.contracts || [];
  if (!list.length) { wrap.innerHTML = '<div class="empty">No loads on the board. Request new loads.</div>'; return; }

  wrap.innerHTML = list.map((c) => `
    <button class="ticket ${c.locked ? 'locked' : ''} ${state.contract === c.id ? 'sel' : ''}" data-id="${c.id}" ${c.locked ? 'aria-disabled="true"' : ''}>
      <div class="t-top">
        <span class="t-cargo">${esc(c.cargoLabel)}</span>
        <span class="t-pay">${money(c.pay)}</span>
      </div>
      <div class="t-route">Deliver to <b>${esc(c.destLabel)}</b>, ${esc(c.region)}</div>
      <div class="t-meta">
        <div><span>Distance</span><strong>${c.km} km</strong></div>
        <div><span>Time limit</span><strong>${c.minutes} min</strong></div>
        <div><span>Experience</span><strong>${c.xp} XP</strong></div>
      </div>
      <div class="t-tags">
        ${c.rush ? '<span class="tag rush">Rush</span>' : ''}
        ${c.hazmat ? '<span class="tag haz">Hazmat</span>' : ''}
        ${c.fragile ? '<span class="tag frag">Fragile</span>' : ''}
        ${c.locked ? `<span class="tag lock">Needs level ${c.minLevel}</span>` : ''}
      </div>
    </button>`).join('');

  wrap.querySelectorAll('.ticket').forEach((el) => {
    el.addEventListener('click', () => {
      const c = list.find((x) => x.id === Number(el.dataset.id));
      if (!c || c.locked) return;
      state.contract = c.id;
      renderTickets();
      updateDock();
    });
  });
}

function renderFleet() {
  const wrap = $('fleet');
  wrap.innerHTML = state.data.trucks.map((t) => `
    <button class="rig ${t.locked ? 'locked' : ''} ${state.truck === t.model ? 'sel' : ''}" data-model="${esc(t.model)}">
      <h4>${esc(t.label)}</h4>
      <p>${esc(t.note || '')}</p>
      <div class="rig-row"><span>Deposit</span><strong>${money(t.deposit)}</strong></div>
      <div class="rig-row"><span>${t.locked ? 'Unlocks at' : 'Requirement'}</span><strong>Level ${t.minLevel}</strong></div>
      <div class="power"><i style="width:${t.power}%"></i></div>
    </button>`).join('');

  wrap.querySelectorAll('.rig').forEach((el) => {
    el.addEventListener('click', () => {
      const t = state.data.trucks.find((x) => x.model === el.dataset.model);
      if (!t || t.locked) return;
      state.truck = t.model;
      renderFleet();
      updateDock();
    });
  });
}

function renderProfile() {
  const p = state.data.profile;
  const avg = p.deliveries ? Math.floor(p.earned / p.deliveries) : 0;
  $('stats').innerHTML = [
    ['Level', p.level],
    ['Experience', p.xp.toLocaleString() + ' XP'],
    ['Deliveries', p.deliveries.toLocaleString()],
    ['Total earned', money(p.earned)],
    ['Average per load', money(avg)],
    ['Distance driven', p.km.toLocaleString() + ' km'],
  ].map(([k, v]) => `<div class="stat"><span>${k}</span><strong>${v}</strong></div>`).join('');

  const chips = [];
  (state.data.cargo || []).forEach((c) => chips.push(`<span class="chip ${p.level >= c.minLevel ? 'ok' : 'no'}">${esc(c.label)}, level ${c.minLevel}</span>`));
  state.data.trucks.forEach((t) => chips.push(`<span class="chip ${p.level >= t.minLevel ? 'ok' : 'no'}">${esc(t.label)}, level ${t.minLevel}</span>`));
  $('unlocks').innerHTML = chips.join('');
}

function renderLeaders() {
  const body = $('leaders').querySelector('tbody');
  const rows = state.data.leaderboard || [];
  if (!rows.length) { body.innerHTML = '<tr><td colspan="4" class="empty">No deliveries logged yet. Be the first.</td></tr>'; return; }
  body.innerHTML = rows.map((r) => `
    <tr>
      <td>${esc(r.name)}</td>
      <td>${levelFromXp(r.xp, state.data.levels)}</td>
      <td>${Number(r.deliveries).toLocaleString()}</td>
      <td>${money(r.earned)}</td>
    </tr>`).join('');
}

function updateDock() {
  const d = state.data;
  const c = d && d.contracts ? d.contracts.find((x) => x.id === state.contract) : null;
  const t = d && d.trucks ? d.trucks.find((x) => x.model === state.truck) : null;
  $('dockLoad').textContent = c ? `${c.cargoLabel} to ${c.destLabel}` : 'Select a waybill';
  $('dockRig').textContent = t ? t.label : 'Select a truck';
  $('dockDeposit').textContent = t ? money(t.deposit) : '$0';
  $('startBtn').disabled = !(c && t) || !!(d && d.active);
}

/* ---------- HUD ---------- */
function barClass(v) { return v < 30 ? 'low' : v < 60 ? 'mid' : ''; }
function setBar(id, v) {
  const el = $(id);
  el.style.width = v + '%';
  el.className = barClass(v);
}

function updateHud(h) {
  $('hCargo').textContent = h.cargo;
  $('hDest').textContent = h.stage === 'return' ? 'Return the truck to ' + h.dest : h.dest;
  $('hDist').textContent = fmtDist(h.meters);
  $('hSpeed').textContent = h.speed + ' km/h';

  const tags = [];
  if (h.rush) tags.push('Rush');
  if (h.hazmat) tags.push('Hazmat');
  if (h.fragile) tags.push('Fragile');
  $('hTags').textContent = tags.join(', ');

  const timeCell = $('hTimeCell');
  if (h.left == null) {
    timeCell.style.visibility = 'hidden';
  } else {
    timeCell.style.visibility = 'visible';
    $('hTime').textContent = fmtTime(h.left);
    timeCell.classList.toggle('late', h.left < 0);
  }

  setBar('hTruckBar', h.truckHealth);
  if (h.trailerHealth == null) {
    $('hTrailerMeter').classList.add('hidden');
  } else {
    $('hTrailerMeter').classList.remove('hidden');
    setBar('hTrailerBar', h.trailerHealth);
  }
  $('hWarn').classList.toggle('hidden', h.attached || h.stage !== 'deliver');
}

/* ---------- progress ---------- */
function startProgress(label, ms) {
  clearInterval(progressTimer);
  $('progLabel').textContent = label;
  $('progress').classList.remove('hidden');
  const fill = $('progFill');
  const t0 = performance.now();
  progressTimer = setInterval(() => {
    const pct = Math.min(100, ((performance.now() - t0) / ms) * 100);
    fill.style.width = pct + '%';
    if (pct >= 100) { clearInterval(progressTimer); setTimeout(() => $('progress').classList.add('hidden'), 250); }
  }, 40);
}
function hideProgress() {
  clearInterval(progressTimer);
  $('progress').classList.add('hidden');
  $('progFill').style.width = '0';
}

/* ---------- receipt ---------- */
function showReceipt(r) {
  $('rRoute').textContent = `${r.cargo} to ${r.dest}`;
  const stamp = $('rStamp');
  stamp.textContent = r.late ? 'Late' : 'Delivered';
  stamp.classList.toggle('late', !!r.late);

  const lines = [['Base rate', money(r.base), '']];
  if (r.bonus > 0) lines.push(['On-time bonus', '+' + money(r.bonus), 'plus']);
  if (r.penalty > 0) {
    const why = [];
    if (r.damage > 0) why.push(r.damage + '% cargo damage');
    if (r.late) why.push('late');
    lines.push([`Deductions (${why.join(', ') || 'fees'})`, '-' + money(r.penalty), 'minus']);
  }
  lines.push(['Trip time', `${r.minutes}:${String(r.seconds).padStart(2, '0')}`, '']);
  lines.push(['Experience', '+' + r.xp + ' XP', '']);
  $('rLines').innerHTML = lines.map(([k, v, c]) => `<div><dt>${esc(k)}</dt><dd class="${c}">${esc(v)}</dd></div>`).join('');

  $('rTotal').textContent = money(r.total);
  $('rAcct').textContent = state.data && state.data.account === 'cash' ? 'cash' : 'bank';
  $('rFoot').textContent = (r.levelUp ? `Level up. You are now level ${r.levelUp}. ` : '') +
    `Return the truck to the depot to reclaim your ${money(r.deposit)} deposit.`;

  $('receipt').classList.remove('hidden');
  clearTimeout(receiptTimer);
  receiptTimer = setTimeout(() => $('receipt').classList.add('hidden'), 12000);
}

/* ---------- events ---------- */
document.querySelectorAll('.tab').forEach((b) => b.addEventListener('click', () => switchTab(b.dataset.tab)));
$('closeBtn').addEventListener('click', () => post('close'));
$('refreshBtn').addEventListener('click', () => { state.contract = null; post('refresh'); });
$('abandonBtn').addEventListener('click', () => post('abandon'));
$('startBtn').addEventListener('click', () => {
  if ($('startBtn').disabled) return;
  post('accept', { id: state.contract, truck: state.truck });
});
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && !$('tablet').classList.contains('hidden')) post('close');
});

window.addEventListener('message', (e) => {
  const m = e.data;
  switch (m.action) {
    case 'open': openTablet(); break;
    case 'close': closeTablet(); break;
    case 'data': state.data = m.data; render(); break;
    case 'hud':
      if (m.show) { $('hud').classList.remove('hidden'); updateHud(m.data); }
      else $('hud').classList.add('hidden');
      break;
    case 'progress':
      if (m.hide) hideProgress(); else startProgress(m.label, m.duration);
      break;
    case 'receipt': showReceipt(m.data); break;
  }
});
