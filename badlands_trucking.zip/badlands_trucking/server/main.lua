--[[ BadLands Studio's | Advanced Trucking | Server ]]

local Profiles, Boards, Jobs, LastRefresh = {}, {}, {}, {}
local LeaderboardCache, LeaderboardAt = {}, 0

---------------------------------------------------------------------------
-- DATABASE
---------------------------------------------------------------------------
CreateThread(function()
    MySQL.query.await([[
        CREATE TABLE IF NOT EXISTS `badlands_trucking` (
            `identifier` VARCHAR(60) NOT NULL,
            `name` VARCHAR(100) NOT NULL DEFAULT 'Driver',
            `xp` INT NOT NULL DEFAULT 0,
            `deliveries` INT NOT NULL DEFAULT 0,
            `earned` BIGINT NOT NULL DEFAULT 0,
            `distance` DOUBLE NOT NULL DEFAULT 0,
            PRIMARY KEY (`identifier`)
        )
    ]])
end)

local function clamp(v, lo, hi) return math.max(lo, math.min(hi, v)) end

local function levelInfo(xp)
    local level = 1
    for l = 1, #Config.Levels do
        if xp >= Config.Levels[l] then level = l end
    end
    local base = Config.Levels[level]
    local nxt = Config.Levels[level + 1]
    return level, base, nxt
end

local function getProfile(src)
    local id = Bridge.GetId(src)
    if not id then return end
    if not Profiles[id] then
        local row = MySQL.single.await('SELECT * FROM badlands_trucking WHERE identifier = ?', { id })
        if not row then
            local name = Bridge.GetName(src)
            MySQL.insert.await('INSERT INTO badlands_trucking (identifier, name) VALUES (?, ?)', { id, name })
            row = { identifier = id, name = name, xp = 0, deliveries = 0, earned = 0, distance = 0 }
        end
        Profiles[id] = row
    end
    return Profiles[id], id
end

local function saveProfile(p)
    MySQL.update('UPDATE badlands_trucking SET name = ?, xp = ?, deliveries = ?, earned = ?, distance = ? WHERE identifier = ?',
        { p.name, p.xp, p.deliveries, p.earned, p.distance, p.identifier })
end

local function getLeaderboard()
    if os.time() - LeaderboardAt > 60 then
        LeaderboardCache = MySQL.query.await('SELECT name, xp, deliveries, earned FROM badlands_trucking ORDER BY earned DESC LIMIT 10') or {}
        LeaderboardAt = os.time()
    end
    return LeaderboardCache
end

local function findTruck(model)
    for _, t in ipairs(Config.Trucks) do if t.model == model then return t end end
end

---------------------------------------------------------------------------
-- CONTRACT BOARD
---------------------------------------------------------------------------
local function buildBoard(level)
    local board = {}
    for i = 1, Config.BoardSize do
        local cargo = Config.Cargo[math.random(#Config.Cargo)]
        local dest = Config.Destinations[math.random(#Config.Destinations)]
        local straight = #(Config.Depot.coords - dest.coords)
        local road = straight * Config.RoadFactor
        local pay = (Config.BasePay + (road / 1000.0) * Config.PayPerKm) * cargo.payMult * (1.0 + (level - 1) * Config.LevelPayBonus)
        local rush = math.random(100) <= Config.RushChance
        local timeLimit = math.floor(road / Config.AvgSpeed) + Config.TimeBuffer
        if rush then
            pay = pay * Config.RushPayMult
            timeLimit = math.floor(timeLimit * Config.RushTimeMult)
        end
        pay = math.floor(pay * (0.95 + math.random() * 0.1))

        board[i] = {
            id = i,
            cargoId = cargo.id,
            cargo = cargo,
            dest = dest,
            straight = straight,
            distance = road,
            pay = pay,
            xp = math.floor(cargo.xp + (road / 1000.0) * Config.XpPerKm),
            timeLimit = timeLimit,
            rush = rush,
        }
    end
    return board
end

-- Strips coordinates before sending the board to the UI
local function boardForUi(board, level)
    local out = {}
    for i, c in ipairs(board) do
        out[i] = {
            id = c.id,
            cargoId = c.cargoId,
            cargoLabel = c.cargo.label,
            icon = c.cargo.icon,
            destLabel = c.dest.label,
            region = c.dest.region,
            km = math.floor(c.distance / 100.0) / 10.0,
            pay = c.pay,
            xp = c.xp,
            minutes = math.ceil(c.timeLimit / 60.0),
            rush = c.rush,
            fragile = c.cargo.fragile or false,
            hazmat = c.cargo.hazmat or false,
            minLevel = c.cargo.minLevel,
            locked = c.cargo.minLevel > level,
        }
    end
    return out
end

local function sendData(src, refresh)
    local profile = getProfile(src)
    if not profile then return end
    local level, base, nxt = levelInfo(profile.xp)

    if refresh or not Boards[src] then
        if refresh and LastRefresh[src] and os.time() - LastRefresh[src] < Config.RefreshCooldown then
            Bridge.Notify(src, 'Dispatch is still sorting new loads. Try again shortly.', 'error')
        else
            Boards[src] = buildBoard(level)
            LastRefresh[src] = os.time()
        end
    end

    local trucks = {}
    for _, t in ipairs(Config.Trucks) do
        trucks[#trucks + 1] = {
            model = t.model, label = t.label, deposit = t.deposit, minLevel = t.minLevel,
            power = t.power, note = t.note, locked = t.minLevel > level,
        }
    end

    local cargoList = {}
    for _, c in ipairs(Config.Cargo) do
        cargoList[#cargoList + 1] = { label = c.label, minLevel = c.minLevel }
    end
    local levels = {}
    for l = 1, #Config.Levels do levels[l] = Config.Levels[l] end

    TriggerClientEvent('badlands_trucking:receiveData', src, {
        cargo = cargoList,
        levels = levels,
        depot = Config.Depot.label,
        account = Config.Account,
        balance = Bridge.GetMoney(src, Config.Account),
        profile = {
            name = profile.name, level = level, xp = profile.xp, base = base, next = nxt,
            deliveries = profile.deliveries, earned = profile.earned,
            km = math.floor((profile.distance / 1000.0) * 10) / 10,
        },
        contracts = boardForUi(Boards[src], level),
        trucks = trucks,
        leaderboard = getLeaderboard(),
        hasJob = Jobs[src] ~= nil,
    })
end

RegisterNetEvent('badlands_trucking:requestData', function(refresh)
    sendData(source, refresh == true)
end)

---------------------------------------------------------------------------
-- ACCEPT CONTRACT
---------------------------------------------------------------------------
RegisterNetEvent('badlands_trucking:accept', function(contractId, truckModel)
    local src = source
    if Jobs[src] then return Bridge.Notify(src, 'You already have an active contract.', 'error') end

    if Config.RequireJob and Bridge.GetJob(src) ~= Config.JobName then
        return Bridge.Notify(src, 'You need to be employed as a trucker to take contracts.', 'error')
    end

    local profile = getProfile(src)
    local board = Boards[src]
    local contract = board and board[tonumber(contractId)]
    local truck = findTruck(truckModel)
    if not profile or not contract or not truck then return end

    local level = levelInfo(profile.xp)
    if contract.cargo.minLevel > level then
        return Bridge.Notify(src, ('This load needs trucking level %d.'):format(contract.cargo.minLevel), 'error')
    end
    if truck.minLevel > level then
        return Bridge.Notify(src, ('%s unlocks at level %d.'):format(truck.label, truck.minLevel), 'error')
    end
    if not Bridge.RemoveMoney(src, Config.Account, truck.deposit, 'trucking-deposit') then
        return Bridge.Notify(src, ('You need $%d for the truck deposit.'):format(truck.deposit), 'error')
    end

    Jobs[src] = {
        contract = contract,
        truck = truck,
        stage = 'deliver',
        startedAt = os.time(),
        deposit = truck.deposit,
    }
    Boards[src] = nil -- fresh board next time

    TriggerClientEvent('badlands_trucking:startJob', src, {
        truck = truck.model,
        truckLabel = truck.label,
        trailer = contract.cargo.trailer,
        cargoLabel = contract.cargo.label,
        icon = contract.cargo.icon,
        destLabel = contract.dest.label,
        dest = contract.dest.coords,
        timeLimit = contract.timeLimit,
        rush = contract.rush,
        pay = contract.pay,
        fragile = contract.cargo.fragile or false,
        hazmat = contract.cargo.hazmat or false,
    })
end)

---------------------------------------------------------------------------
-- COMPLETE DELIVERY
---------------------------------------------------------------------------
RegisterNetEvent('badlands_trucking:complete', function(report)
    local src = source
    local job = Jobs[src]
    if not job or job.stage ~= 'deliver' or type(report) ~= 'table' then return end

    local contract = job.contract
    local pedCoords = GetEntityCoords(GetPlayerPed(src))
    if #(pedCoords - contract.dest.coords) > Config.DeliveryRadius + 45.0 then
        if Config.Debug then print(('[badlands_trucking] %s completed away from the drop-off'):format(src)) end
        return Bridge.Notify(src, 'You are not at the drop-off point.', 'error')
    end

    local elapsed = os.time() - job.startedAt
    if elapsed < (contract.straight / Config.MaxPossibleSpeed) then
        print(('^1[badlands_trucking]^7 Suspicious delivery speed from %s (%ds for %dm)'):format(src, elapsed, contract.straight))
        return Bridge.Notify(src, 'Delivery rejected by dispatch.', 'error')
    end

    local trailerHealth = clamp(tonumber(report.trailerHealth) or 100, 0, 100)
    local damagePct = 100 - trailerHealth

    local pay = contract.pay
    local penalty = pay * (damagePct / 100.0) * Config.DamagePenalty * contract.cargo.damageMult
    local bonus = 0
    local onTime, late = false, false
    if elapsed <= contract.timeLimit * 0.75 then
        bonus = pay * Config.OnTimeBonus
        onTime = true
    elseif elapsed > contract.timeLimit then
        penalty = penalty + pay * Config.LatePenalty
        late = true
    end

    local final = math.floor(math.max(pay * 0.15, pay - penalty + bonus))
    local xpGain = math.floor(contract.xp * (1.0 - damagePct / 250.0))

    local profile = getProfile(src)
    if not profile then return end
    local oldLevel = levelInfo(profile.xp)
    profile.xp = profile.xp + xpGain
    profile.deliveries = profile.deliveries + 1
    profile.earned = profile.earned + final
    profile.distance = profile.distance + contract.distance
    profile.name = Bridge.GetName(src)
    saveProfile(profile)

    Bridge.AddMoney(src, Config.Account, final, 'trucking-delivery')
    job.stage = 'return'

    local newLevel = levelInfo(profile.xp)
    TriggerClientEvent('badlands_trucking:delivered', src, {
        cargo = contract.cargo.label,
        dest = contract.dest.label,
        base = pay,
        bonus = math.floor(bonus),
        penalty = math.floor(penalty),
        total = final,
        xp = xpGain,
        damage = math.floor(damagePct),
        onTime = onTime,
        late = late,
        minutes = math.floor(elapsed / 60),
        seconds = elapsed % 60,
        levelUp = newLevel > oldLevel and newLevel or nil,
        deposit = job.deposit,
    })
end)

---------------------------------------------------------------------------
-- RETURN / CANCEL
---------------------------------------------------------------------------
RegisterNetEvent('badlands_trucking:returnTruck', function(truckHealth)
    local src = source
    local job = Jobs[src]
    if not job or job.stage ~= 'return' then return end

    if #(GetEntityCoords(GetPlayerPed(src)) - Config.Depot.returnPoint) > Config.ReturnRadius + 40.0 then
        return Bridge.Notify(src, 'Bring the truck back to the depot.', 'error')
    end

    local pct = clamp(tonumber(truckHealth) or 100, 0, 100)
    local refund = math.floor(job.deposit * clamp(pct, 50, 100) / 100.0)
    Bridge.AddMoney(src, Config.Account, refund, 'trucking-deposit-refund')
    Jobs[src] = nil
    TriggerClientEvent('badlands_trucking:returned', src, refund, job.deposit - refund)
end)

RegisterNetEvent('badlands_trucking:cancel', function(reason)
    local src = source
    local job = Jobs[src]
    if not job then return end
    Jobs[src] = nil
    if job.stage == 'return' then
        -- Delivery was already paid; the truck is just not coming back. Deposit is kept.
        return Bridge.Notify(src, 'Truck abandoned. Your deposit was kept by the depot.', 'error')
    end
    Bridge.Notify(src, 'Contract cancelled. Your deposit was forfeited.', 'error')
end)

-- Spawn failed on the client (blocked bay / model error): full refund, only valid right after accepting
RegisterNetEvent('badlands_trucking:abort', function()
    local src = source
    local job = Jobs[src]
    if not job or job.stage ~= 'deliver' or os.time() - job.startedAt > 30 then return end
    Jobs[src] = nil
    Bridge.AddMoney(src, Config.Account, job.deposit, 'trucking-deposit-refund')
    Bridge.Notify(src, 'Deposit refunded. Try again in a moment.', 'info')
end)

AddEventHandler('playerDropped', function()
    local src = source
    Jobs[src], Boards[src], LastRefresh[src] = nil, nil, nil
end)

AddEventHandler('onResourceStop', function(res)
    if res ~= GetCurrentResourceName() then return end
    for _, p in pairs(Profiles) do saveProfile(p) end
end)
