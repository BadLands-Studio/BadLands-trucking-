--[[ BadLands Studio's | Advanced Trucking | Server bridge ]]

Bridge = {}
Bridge.Framework = nil

local core

local function detect()
    if Config.Framework ~= 'auto' then return Config.Framework end
    if GetResourceState('qbx_core') == 'started' then return 'qbox' end
    if GetResourceState('qb-core') == 'started' then return 'qbcore' end
    if GetResourceState('es_extended') == 'started' then return 'esx' end
end

CreateThread(function()
    local waited = 0
    while not Bridge.Framework and waited < 30000 do
        Bridge.Framework = detect()
        if not Bridge.Framework then Wait(500) waited = waited + 500 end
    end

    if Bridge.Framework == 'esx' then
        core = exports['es_extended']:getSharedObject()
    elseif Bridge.Framework == 'qbcore' then
        core = exports['qb-core']:GetCoreObject()
    end

    if Bridge.Framework then
        print(('^2[badlands_trucking]^7 Framework detected: ^3%s^7'):format(Bridge.Framework))
    else
        print('^1[badlands_trucking]^7 No supported framework found (es_extended, qb-core, qbx_core).')
    end
end)

function Bridge.GetPlayer(src)
    local fw = Bridge.Framework
    if fw == 'esx' then return core.GetPlayerFromId(src) end
    if fw == 'qbcore' then return core.Functions.GetPlayer(src) end
    if fw == 'qbox' then return exports.qbx_core:GetPlayer(src) end
end

function Bridge.GetId(src)
    local p = Bridge.GetPlayer(src)
    if not p then return end
    if Bridge.Framework == 'esx' then return p.identifier end
    return p.PlayerData.citizenid
end

function Bridge.GetName(src)
    local p = Bridge.GetPlayer(src)
    if not p then return 'Driver' end
    if Bridge.Framework == 'esx' then return p.getName() end
    local ci = p.PlayerData.charinfo
    return ('%s %s'):format(ci.firstname, ci.lastname)
end

function Bridge.GetJob(src)
    local p = Bridge.GetPlayer(src)
    if not p then return end
    if Bridge.Framework == 'esx' then return p.job and p.job.name end
    return p.PlayerData.job and p.PlayerData.job.name
end

function Bridge.GetMoney(src, account)
    local p = Bridge.GetPlayer(src)
    if not p then return 0 end
    if Bridge.Framework == 'esx' then
        if account == 'cash' then return p.getMoney() end
        local acc = p.getAccount(account)
        return acc and acc.money or 0
    end
    return p.Functions.GetMoney(account) or 0
end

function Bridge.AddMoney(src, account, amount, reason)
    local p = Bridge.GetPlayer(src)
    if not p then return false end
    amount = math.floor(amount)
    if Bridge.Framework == 'esx' then
        if account == 'cash' then p.addMoney(amount) else p.addAccountMoney(account, amount) end
        return true
    end
    return p.Functions.AddMoney(account, amount, reason or 'badlands-trucking')
end

function Bridge.RemoveMoney(src, account, amount, reason)
    local p = Bridge.GetPlayer(src)
    if not p then return false end
    amount = math.floor(amount)
    if Bridge.GetMoney(src, account) < amount then return false end
    if Bridge.Framework == 'esx' then
        if account == 'cash' then p.removeMoney(amount) else p.removeAccountMoney(account, amount) end
        return true
    end
    return p.Functions.RemoveMoney(account, amount, reason or 'badlands-trucking')
end

function Bridge.Notify(src, msg, nType)
    TriggerClientEvent('badlands_trucking:notify', src, msg, nType or 'info')
end
