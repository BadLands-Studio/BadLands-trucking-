# BadLands Trucking

**Author:** BadLands Studio's
**Frameworks:** ESX, QBCore, QBox (auto-detected)
**Requires:** `oxmysql`, OneSync enabled

An advanced semi trucking job built around a dispatch tablet.

## Features

- Dispatch tablet UI: job board of waybill tickets, fleet picker, driver record, top-earners leaderboard
- Level and XP progression that unlocks heavier cargo and better trucks
- Rented rigs with a deposit that is refunded when you return the truck, reduced by damage
- Six cargo types, each with its own trailer, pay multiplier and damage sensitivity (hazmat, fragile)
- Rush contracts with tighter deadlines and higher pay
- Live in-cab HUD: distance, time left, speed, truck and cargo condition, trailer-unhitched warning
- Unload progress bar and a proof-of-delivery receipt with bonus and deduction breakdown
- Server-side validation: payouts, distance, minimum trip time and deposits are all checked on the server
- Auto-creates its database table and saves progress per character

## Install

1. Drop the `badlands_trucking` folder into your resources.
2. Make sure `oxmysql` is installed and OneSync is on.
3. Add to `server.cfg` after your framework and oxmysql:
   ```
   ensure badlands_trucking
   ```
4. The `badlands_trucking` table is created on first start. No SQL import needed.

## Setup

Everything is in `config.lua`.

- **Depot position:** the default coordinates are a starting point. Stand where you want the dispatch desk, truck bay and return point, and replace the vectors in `Config.Depot`. Keep the truck bay clear of props and parked cars.
- **Trailer will not hitch:** adjust `Config.TrailerOffset`, or set `Config.AutoAttachTrailer = false` so drivers hitch it by hand.
- **Job gate:** set `Config.RequireJob = true` and `Config.JobName` to limit it to a job.
- **Payouts:** `Config.Account` is `bank` or `cash`.
- **Keys and fuel:** `Config.GiveKeys` and `Config.SetFuel` already try the common scripts (qbx_vehiclekeys, qb-vehiclekeys, wasabi_carlock, cd_garage, okokGarage, ox_fuel, LegacyFuel, cdn-fuel, ps-fuel). Add your own in there if you use something else.
- **Cargo, trucks and destinations:** add or edit entries in `Config.Cargo`, `Config.Trucks` and `Config.Destinations`.

## Commands

- `/canceltruck` abandons the active contract (deposit is forfeited)

## Notes

- Trailer and truck models are GTA V base-game models. If a trailer looks wrong on your build, swap the model name in `Config.Cargo`.
- Contracts are generated per player on the server, and destination coordinates are only sent to the client once a contract is accepted.
